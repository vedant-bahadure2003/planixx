export { default as HeroSection } from "./HeroSection";
export { default as UpcomingEvents } from "./UpcomingEvents";
export { default as AboutSection } from "./AboutSection";
export { default as EnquirySection } from "./EnquirySection";
export { default as PrivacyPolicy } from "./DataPolicy";
