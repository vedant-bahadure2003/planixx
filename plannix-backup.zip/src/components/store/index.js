export { default as StoreHero } from "./StoreHero";
export { default as StoreCategories } from "./StoreCategories";
export { default as WhyChooseUs } from "./WhyChooseUs";
export { default as TestimonialsStore } from "./TestimonialsStore";
export { default as StoreCTA } from "./StoreCTA";
