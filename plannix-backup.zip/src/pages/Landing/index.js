export { default as Landing } from "./Landing";
